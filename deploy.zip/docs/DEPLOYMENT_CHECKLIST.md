# Deployment Checklist

## Pre-Deployment

- [ ] Run `php artisan tmc:health-check` and confirm all checks pass
- [ ] Run `php artisan test` and confirm all tests pass
- [ ] Run `./vendor/bin/pint` to format any outstanding PHP style issues
- [ ] Check `git status` — no uncommitted changes in production branch
- [ ] Verify `.env` has all required variables (compare against `.env.example`)

## Deployment Sequence (cPanel / Shared Hosting)

```bash
# 1. Pull latest code
git pull origin main

# 2. Install/update PHP dependencies (no dev on production)
composer install --no-dev --optimize-autoloader

# 3. Run migrations
php artisan migrate --force

# 4. Seed required data (idempotent)
php artisan db:seed --class=RoleSeeder --force
php artisan db:seed --class=AdminUserSeeder --force

# 5. Clear caches
php artisan optimize:clear

# 6. Cache for production
php artisan config:cache
php artisan route:cache
php artisan event:cache
php artisan view:cache

# 7. Rebuild permission cache (spatie/laravel-permission)
php artisan permission:cache-reset

# 8. Storage link (if not already done)
php artisan storage:link

# 9. Verify deployment
php artisan tmc:health-check
```

## Queue Worker Setup (cPanel)

Add the following as a Cron job (runs every minute):

```bash
* * * * * flock -n /tmp/laravel_queue.lock /usr/local/bin/php /home/USERNAME/themuhsinatclub/artisan queue:work database --queue=membership,billing,default --sleep=3 --tries=3 --max-time=55 >> /dev/null 2>&1
```

This runs three queue priorities: `membership` (emails, audit logs), `billing` (subscription notifications), `default` (fallback).

## Paystack Webhook Setup

1. Go to Paystack Dashboard → Settings → Webhooks
2. Set Webhook URL to: `https://themuhsinatclub.com/webhooks/paystack`
3. Copy the webhook secret into `.env` as `PAYSTACK_WEBHOOK_SECRET`

## Required Environment Variables

| Variable | Description |
|---|---|
| `APP_KEY` | Laravel app key (run `php artisan key:generate`) |
| `APP_ENV` | `production` |
| `APP_DEBUG` | `false` |
| `APP_URL` | `https://themuhsinatclub.com` |
| `DB_*` | Database connection (PostgreSQL recommended for production) |
| `QUEUE_CONNECTION` | `database` |
| `PAYSTACK_SECRET_KEY` | Paystack secret key (live) |
| `PAYSTACK_PUBLIC_KEY` | Paystack public key (live) |
| `PAYSTACK_WEBHOOK_SECRET` | Paystack webhook secret |
| `MAIL_MAILER` | `resend` or `smtp` |
| `MAIL_FROM_ADDRESS` | `noreply@themuhsinatclub.com` |

## Post-Deployment Smoke Tests

- [ ] Visit landing page (`/`) — loads without errors
- [ ] Visit login page (`/login`) — renders Fortify login
- [ ] Visit admin panel (`/admin`) — login with admin credentials
- [ ] Check `/admin` has "Pending Members" and "Payment Approvals" sections
- [ ] Visit a payment page in processing state — "Check Status" button works
- [ ] Run `php artisan tmc:health-check` — all green

## Rollback

```bash
# Roll back last migration
php artisan migrate:rollback --step=1 --force

# Roll back to specific date
php artisan migrate:rollback --step=5 --force

# Full rollback + remigrate
php artisan migrate:fresh --seed --force
```
