<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>