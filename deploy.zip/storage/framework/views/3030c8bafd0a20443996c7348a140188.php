<?php $__env->startComponent('mail::message'); ?>

# Assalamu Alaikum <?php echo new \Illuminate\Support\EncodedHtmlString($user->name); ?>,

Your membership application has been approved! Welcome to The Muhsinat Club.

**Membership ID:** <?php echo new \Illuminate\Support\EncodedHtmlString($membershipId); ?>


**Membership Type:** <?php echo new \Illuminate\Support\EncodedHtmlString($membershipType); ?>


Your legacy card is ready:

<?php $__env->startComponent('mail::button', ['url' => $legacyCardUrl]); ?>
View Your Legacy Card
<?php echo $__env->renderComponent(); ?>

To complete your registration, please complete your membership payment:

<?php $__env->startComponent('mail::button', ['url' => $paymentUrl, 'color' => 'success']); ?>
Complete Payment
<?php echo $__env->renderComponent(); ?>

You can choose between monthly, quarterly, or yearly billing.

**Important:** Your login credentials are not included in this email for security reasons.

If you have any questions, please contact our support team.

JazakAllahu Khairan,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/emails/membership/approved.blade.php ENDPATH**/ ?>