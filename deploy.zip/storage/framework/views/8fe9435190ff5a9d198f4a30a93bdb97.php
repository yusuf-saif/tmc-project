<div class="space-y-6">
    <a href="<?php echo e(route('resources')); ?>" class="inline-flex items-center text-[13px] font-medium text-teal">&larr; Resources</a>

    <section class="overflow-hidden rounded-[8px] bg-white p-5" style="border:1px solid var(--border);">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($resource->type, ['article', 'guide'], true)): ?>
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($resource->title); ?></h1>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->bodyContainsHtml()): ?>
                <div class="prose mt-5 max-w-none prose-p:font-light prose-p:leading-8 prose-p:text-ink-md prose-headings:font-display prose-headings:text-teal-dk"><?php echo $resource->body; ?></div>
            <?php else: ?>
                <div class="mt-5 text-base font-light leading-8 text-ink-md"><?php echo nl2br(e($resource->body ?? '')); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php elseif($resource->type === 'dua'): ?>
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($resource->title); ?></h1>
            <div class="mt-5 text-right font-arabic text-[1.4rem] leading-[2] text-ink" dir="rtl"><?php echo nl2br(e($resource->body ?? '')); ?></div>
            <p class="mt-4 text-sm font-light italic leading-7 text-ink-soft"><?php echo e($resource->description); ?></p>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isSaved): ?>
                <button type="button" wire:click="saveToDuaList"
                        class="btn-teal-outline mt-6"
                        wire:loading.attr="disabled">
                    ✦ Save to My Du'a List
                </button>
            <?php else: ?>
                <button type="button" wire:click="removeFromDuaList"
                        class="mt-6 inline-flex min-h-11 items-center justify-center px-5 text-[12.5px] font-semibold uppercase tracking-[1.2px] text-teal-dk transition"
                        style="background:var(--teal-lt);border:1px solid var(--teal);border-radius:var(--radius-sm);"
                        wire:loading.attr="disabled">
                    ✦ Saved to Du'a List ✓
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php elseif($resource->type === 'pdf'): ?>
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($resource->title); ?></h1>
            <p class="mt-3 text-sm font-light leading-7 text-ink-soft"><?php echo e($resource->description); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($resource->file_path): ?>
                <a href="<?php echo e(Storage::url($resource->file_path)); ?>" target="_blank"
                   class="btn-gold-full mt-5" style="max-width:200px;">
                    Download PDF
                </a>
                <iframe src="<?php echo e(Storage::url($resource->file_path)); ?>" class="pdf-preview"></iframe>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php elseif($resource->type === 'audio'): ?>
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($resource->title); ?></h1>
            <p class="mt-3 text-sm font-light leading-7 text-ink-soft"><?php echo e($resource->description); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($resource->file_path): ?>
                <audio controls class="mt-3 w-full">
                    <source src="<?php echo e(Storage::url($resource->file_path)); ?>">
                </audio>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php elseif($resource->type === 'video_link'): ?>
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($resource->title); ?></h1>
            <p class="mt-3 text-sm font-light leading-7 text-ink-soft"><?php echo e($resource->description); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($resource->external_url): ?>
                <a href="<?php echo e($resource->external_url); ?>" target="_blank" rel="noreferrer"
                   class="btn-teal-outline mt-5" style="text-decoration:none;">
                    Watch →
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/resources/resource-detail.blade.php ENDPATH**/ ?>