<div>

  
  <div class="page-wrap anim-fade-up" style="margin-bottom:12px;">
    <h1 class="souq-page-title">Halaqahs &amp; Events</h1>
    <p class="souq-page-subtitle">Stay close to the gatherings and sisterhood moments ahead.</p>
  </div>

  
  <div class="tab-bar anim-slide-down">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['upcoming' => 'Upcoming', 'past' => 'Past', 'my_rsvps' => 'My RSVPs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <button type="button" wire:click="switchTab('<?php echo e($value); ?>')"
              class="tab-item <?php echo e($tab === $value ? 'active' : ''); ?>">
        <?php echo e($label); ?>

      </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  
  <div class="page-pad" style="padding-top:16px;">

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->events->isNotEmpty()): ?>

      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="event-card anim-fade-up" style="animation-delay:<?php echo e($loop->index * 0.06); ?>s;">

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->cover_image_path): ?>
          <img src="<?php echo e(asset('storage/'.$event->cover_image_path)); ?>"
               alt="<?php echo e($event->title); ?>"
               class="event-cover-img">
        <?php else: ?>
          <div class="event-card__placeholder">
            <span>TMC</span>
          </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="event-card__body">
          <p class="event-card__title"><?php echo e($event->title); ?></p>

          <div class="event-card__meta">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
              <rect x="3" y="4" width="18" height="18" rx="2"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
            </svg>
            <span><?php echo e($event->event_date->hijri('D d M Y · g:ia')); ?></span>
          </div>

          <div class="event-footer">
            <div class="event-footer-meta">
              <?php
                $badgeClass = match($event->location_type) {
                  'in_person' => 'badge-gold',
                  'hybrid'    => 'badge-plum',
                  default     => 'badge-teal',
                };
                $locationLabel = match($event->location_type) {
                  'online'    => 'Online',
                  'in_person' => 'In Person',
                  'hybrid'    => 'Hybrid',
                  default     => ucfirst($event->location_type),
                };
              ?>
              <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($locationLabel); ?></span>
              <span class="event-footer-count"><?php echo e($event->active_rsvps_count); ?> going</span>
            </div>

            <div class="event-footer-actions">
              <a href="<?php echo e(route('events.show', $event->slug)); ?>" class="event-footer-link">Details</a>

              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'upcoming'): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->isRsvpd($event->id)): ?>
                  <span class="btn btn-sm btn-teal-ol" style="cursor:default;opacity:0.8;">Going ✓</span>
                <?php else: ?>
                  <button type="button" wire:click="rsvp(<?php echo e($event->id); ?>)" class="btn btn-teal btn-sm">
                    RSVP
                  </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'my_rsvps'): ?>
                <button type="button" wire:click="cancelRsvp(<?php echo e($event->id); ?>)"
                        wire:confirm="Cancel your RSVP?" class="btn btn-sm btn-teal-ol">
                  Cancel
                </button>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php else: ?>
      <div class="card empty-state">
        <p class="empty-state-icon"><?php echo e($this->emptyStateMessage()); ?></p>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

  </div>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/events/events-list.blade.php ENDPATH**/ ?>