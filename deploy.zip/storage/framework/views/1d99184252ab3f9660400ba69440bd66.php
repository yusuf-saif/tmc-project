<nav aria-label="Bottom navigation" class="bottom-nav">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($tab['href']); ?>"
           class="bn-tab <?php echo e($tab['active'] ? 'active' : ''); ?>"
           <?php if($tab['active']): ?> aria-current="page" <?php endif; ?>>
            <span class="bn-icon"><?php echo $tab['icon']; ?></span>
            <span><?php echo e($tab['label']); ?></span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</nav>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/layout/bottom-nav.blade.php ENDPATH**/ ?>