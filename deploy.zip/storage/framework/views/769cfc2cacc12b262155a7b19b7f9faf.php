<span class="text-xs font-medium text-gray-500" style="font-feature-settings:'tnum';">
  <?php echo e(now()->hijri('j M Y')); ?>

</span>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/filament/hijri-date.blade.php ENDPATH**/ ?>