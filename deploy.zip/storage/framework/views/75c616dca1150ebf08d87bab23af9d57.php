<?php echo e($slot); ?>

<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>