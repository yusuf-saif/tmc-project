<?php $__env->startSection('content'); ?>
    <h1 class="tmc-auth-heading">Welcome back Muhsinah</h1>
    <p class="tmc-auth-copy">Sign in to continue your journey with The Muhsinat Club.</p>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
        <p class="mt-6 rounded-sm bg-gold-pale px-4 py-3 text-sm text-teal-dk"><?php echo e(session('status')); ?></p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>" class="mt-8 space-y-5" x-data="{ showPassword: false, submitting: false }" @submit="submitting = true">
        <?php echo csrf_field(); ?>

        <div>
            <label for="email" class="tmc-label">Email Address</label>
            <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username" class="tmc-input">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="tmc-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div>
            <div class="mb-2 flex items-center justify-between">
                <label for="password" class="tmc-label mb-0">Password</label>
                <button type="button" class="text-xs font-semibold uppercase tracking-[1px] text-teal" @click="showPassword = ! showPassword">
                    <span x-text="showPassword ? 'Hide' : 'Show'"></span>
                </button>
            </div>
            <input id="password" name="password" x-bind:type="showPassword ? 'text' : 'password'" required autocomplete="current-password" class="tmc-input">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="tmc-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="flex items-center justify-between gap-4 text-sm text-ink-soft">
            <label class="inline-flex items-center gap-2">
                <input type="checkbox" name="remember" class="h-4 w-4 border-slate-300 text-teal focus:ring-teal" <?php if(old('remember')): echo 'checked'; endif; ?>>
                <span>Remember me</span>
            </label>

            <a href="<?php echo e(route('password.request')); ?>" class="tmc-link">Forgot password?</a>
        </div>

        <button type="submit" class="tmc-button-gold" :disabled="submitting" x-text="submitting ? 'Signing In...' : 'Sign In'"></button>
    </form>

    <p class="mt-6 text-center text-sm text-ink-soft">
        New here?
        <a href="<?php echo e(route('membership.signup')); ?>" class="tmc-link">Create an account</a>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Login'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/auth/login.blade.php ENDPATH**/ ?>