<?php use Illuminate\Support\Str; ?>

<div x-data="{ showModal: false, showDuaForm: $wire.entangle('showDuaForm') }"
     x-on:open-modal.window="showModal = true"
     x-on:close-modal.window="showModal = false"
     class="space-y-6 px-4">
    <section class="space-y-2">
        <h1 class="font-display text-[1.8rem] leading-none text-teal">My Journal</h1>
        <p class="text-sm font-light leading-7 text-ink-soft">Keep a private space for your reflections and the du'as you return to most.</p>
    </section>

    <section class="journal-tabs">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['entries' => 'Entries', 'dua_list' => "Du'a List"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" wire:click="$set('tab', '<?php echo e($value); ?>')"
                    class="journal-tab <?php echo e($tab === $value ? 'journal-tab-active' : 'journal-tab-inactive'); ?>">
                <?php echo e($label); ?>

            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'entries'): ?>
        <button type="button" wire:click="openNewEntry" class="journal-fab-btn" aria-label="New entry">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                 stroke="white" stroke-width="2" stroke-linecap="round">
                <line x1="12" y1="5" x2="12" y2="19"/>
                <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
        </button>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->entries->isNotEmpty()): ?>
            <div class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $emoji = match ($entry->mood) {
                            'happy' => '😊',
                            'grateful' => '🤲',
                            'reflective' => '🌙',
                            'sad' => '😔',
                            'anxious' => '😟',
                            default => '😐',
                        };
                    ?>
                    <article class="journal-entry-card">
                        <div class="journal-mood"><?php echo e($emoji); ?></div>
                        <div style="flex:1;min-width:0;">
                            <p style="font-size:0.875rem;font-weight:600;color:var(--ink);"><?php echo e($entry->entry_date->hijri('d M Y')); ?></p>
                            <p style="margin-top:4px;font-size:0.8rem;font-weight:300;color:var(--ink-soft);line-height:1.6;"><?php echo e(Str::limit($entry->body, 80)); ?></p>
                        </div>
                        <div class="journal-entry-actions">
                            <button type="button" wire:click="openEditEntry(<?php echo e($entry->id); ?>)"
                                    class="journal-action-btn" aria-label="Edit entry">✎</button>
                            <button type="button" wire:click="deleteEntry(<?php echo e($entry->id); ?>)"
                                    wire:confirm="Delete this entry?"
                                    class="journal-action-btn" aria-label="Delete entry">🗑</button>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <section class="card empty-state" style="padding:3rem 1rem;">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" class="mx-auto h-12 w-12 text-teal"><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 3.75V18a2.25 2.25 0 0 1-2.25 2.25H7.5A2.25 2.25 0 0 1 5.25 18V5.25A1.5 1.5 0 0 1 6.75 3.75h9.75Z"/><path stroke-linecap="round" stroke-linejoin="round" d="M9 8.25h4.5M9 12h3"/></svg>
                <p class="mt-4 font-display text-[1.3rem] text-teal">Your journal is waiting</p>
                <p class="mt-2 text-[0.875rem] font-light leading-7 text-ink-soft">Begin your first reflection, insha'Allah</p>
                <button type="button" wire:click="openNewEntry" class="tmc-button-gold mx-auto mt-5 max-w-[180px]">New Entry</button>
            </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php else: ?>
        <div class="flex justify-end">
            <button type="button" @click="showDuaForm = ! showDuaForm" class="journal-dua-add-btn"
                    style="border:1.5px solid var(--teal);border-radius:var(--radius-sm);">
                + Add Du'a
            </button>
        </div>

        <div x-show="showDuaForm" x-transition class="space-y-3" x-cloak>
            <div class="journal-dua-card">
                <textarea wire:model="duaText" class="input-textarea" placeholder="Type your du'a..." style="min-height:100px;margin-bottom:8px;"></textarea>
                <input type="text" wire:model="duaLabel" class="input" placeholder="Label (optional)" style="margin-bottom:8px;">
                <button type="button" wire:click="saveDuaManual" class="btn-gold-full">Save Du'a</button>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->duaItems->isNotEmpty()): ?>
            <div class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->duaItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="journal-dua-card">
                        <div class="flex items-start justify-between gap-4">
                            <div class="min-w-0 flex-1 space-y-3">
                                <p class="text-right font-arabic text-base leading-8 text-ink" dir="rtl"><?php echo e($item->dua_text); ?></p>
                                <div class="flex flex-wrap items-center gap-2">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->label): ?>
                                        <span class="journal-dua-label" style="background:var(--teal-lt);color:var(--teal);"><?php echo e($item->label); ?></span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->resource_id): ?>
                                        <span class="journal-dua-label" style="background:var(--gold-pale);color:var(--gold);">From Library</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->resource): ?>
                                    <a href="<?php echo e(route('resources.show', $item->resource->slug)); ?>" class="text-[11px] text-ink-soft">View original →</a>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <button type="button" wire:click="removeDuaItem(<?php echo e($item->id); ?>)"
                                    wire:confirm="Remove from Du'a List?" class="journal-action-btn">🗑</button>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <section class="card empty-state">
                <p class="text-sm font-light leading-7 text-ink-soft">Your Du'a List is empty — save du'as from the Resources library or add your own</p>
            </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div x-show="showModal" x-transition.opacity class="modal-backdrop" x-cloak></div>
    
    <div x-show="showModal" x-transition class="modal-drawer" x-cloak>
        <div class="drawer-handle"></div>
        <div class="space-y-5">
            <div>
                <h2 class="font-display text-[1.5rem] leading-none text-teal"><?php echo e($editingId ? 'Edit Entry' : 'New Entry'); ?></h2>
            </div>

            <div>
                <label class="tmc-label">Date</label>
                <input type="date" wire:model="entryDate" class="input">
            </div>

            <div class="space-y-3">
                <label class="tmc-label">How are you feeling?</label>
                <div class="journal-mood-grid">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['happy' => '😊', 'grateful' => '🤲', 'reflective' => '🌙', 'sad' => '😔', 'anxious' => '😟', 'neutral' => '😐']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $emoji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" wire:click="$set('mood', '<?php echo e($value); ?>')"
                                class="journal-mood-btn <?php echo e($mood === $value ? 'journal-mood-active' : 'journal-mood-inactive'); ?>">
                            <?php echo e($emoji); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <div>
                <label class="tmc-label">Your reflection</label>
                <textarea wire:model="body" class="input-textarea" style="min-height:140px;" placeholder="Write your thoughts here..."></textarea>
            </div>

            <button type="button" wire:click="saveEntry" class="btn-gold-full">Save Entry</button>
            <button type="button" @click="showModal = false" class="text-sm text-teal">Cancel</button>
        </div>
    </div>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/journal/journal-screen.blade.php ENDPATH**/ ?>