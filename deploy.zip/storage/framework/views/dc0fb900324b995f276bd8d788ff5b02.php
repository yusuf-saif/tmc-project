<?php ($roleBadge = $this->roleBadge()); ?>
<?php ($displayName = $this->profile?->display_name ?: auth()->user()->name); ?>

<div class="anim-fade-in" x-data="{ activeTab: <?php echo \Illuminate\Support\Js::from($tab)->toHtml() ?> }" x-effect="$wire.tab = activeTab">

  
  <div class="profile-banner"></div>
  <div class="profile-avatar-wrap anim-scale-in">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->profile?->avatar_path): ?>
      <img src="<?php echo e(Storage::url($this->profile->avatar_path)); ?>"
           alt="<?php echo e($displayName); ?>"
           class="profile-avatar">
    <?php else: ?>
      <div class="profile-avatar-initials">
        <?php echo e(strtoupper(mb_substr($displayName, 0, 1))); ?>

      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <h1 class="profile-name"><?php echo e($displayName); ?></h1>
    <span class="profile-badge <?php echo e($roleBadge['class'] ?? ''); ?>"
          style="<?php echo e($roleBadge['style']); ?>">
      <?php echo e($roleBadge['label']); ?>

    </span>
  </div>

  
  <div class="tab-scroll">
    <div class="tab-scroll-inner">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [
        'overview' => 'Overview',
        'wallet' => 'Wallet',
        'membership' => 'Membership',
        'notifications' => 'Notifications',
        'referrals' => 'Referrals',
        'settings' => 'Settings',
      ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <button
        wire:click="switchTab('<?php echo e($key); ?>')"
        x-on:click="activeTab = '<?php echo e($key); ?>'"
        class="tab-pill <?php echo e($tab === $key ? 'tab-pill-active' : 'tab-pill-inactive'); ?>">
        <?php echo e($label); ?>

      </button>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </div>

  
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'overview'): ?>
  <div class="anim-fade-up">

    
    <div class="profile-stats">
      <div class="profile-stat-card">
        <p class="profile-stat-val"><?php echo e($this->memberSince); ?></p>
        <p class="profile-stat-lbl">Since</p>
      </div>
      <button wire:click="switchTab('wallet')" x-on:click="activeTab = 'wallet'"
              class="profile-stat-card"
              style="text-decoration:none;cursor:pointer;background:none;border:none;text-align:center;">
        <p class="profile-stat-val"><?php echo e(number_format($this->coinsBalance)); ?></p>
        <p class="profile-stat-lbl">Coins</p>
      </button>
      <button wire:click="switchTab('membership')" x-on:click="activeTab = 'membership'"
              class="profile-stat-card"
              style="text-decoration:none;cursor:pointer;background:none;border:none;text-align:center;">
        <p class="profile-stat-val"><?php echo e($this->badges->count()); ?></p>
        <p class="profile-stat-lbl">Badges</p>
      </button>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->interests->isNotEmpty()): ?>
    <div class="anim-fade-up delay-1 page-pad" style="margin-bottom:16px;">
      <p class="section-label profile-section-label">Interests</p>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span class="pill"><?php echo e($interest->name); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="anim-fade-up delay-2 page-pad" style="margin-bottom:16px;">
      <p class="section-label profile-section-label">Quick Access</p>
      <div class="quick-access-grid">
        <button wire:click="switchTab('wallet')" x-on:click="activeTab = 'wallet'"
                class="quick-access-tile">
          <span class="quick-access-tile-emoji">💰</span>
          <div>
            <p class="quick-access-tile-title">Wallet</p>
            <p class="quick-access-tile-sub"><?php echo e(number_format($this->coinsBalance)); ?> coins</p>
          </div>
        </button>
        <button wire:click="switchTab('notifications')" x-on:click="activeTab = 'notifications'"
                class="quick-access-tile">
          <span class="quick-access-tile-emoji">🔔</span>
          <div>
            <p class="quick-access-tile-title">Notifications</p>
            <p class="quick-access-tile-sub"><?php echo e($this->unreadCount); ?> unread</p>
          </div>
        </button>
        <button wire:click="switchTab('referrals')" x-on:click="activeTab = 'referrals'"
                class="quick-access-tile">
          <span class="quick-access-tile-emoji">🤝</span>
          <div>
            <p class="quick-access-tile-title">Referrals</p>
            <p class="quick-access-tile-sub"><?php echo e($this->referralCount); ?> joined</p>
          </div>
        </button>
        <button wire:click="switchTab('membership')" x-on:click="activeTab = 'membership'"
                class="quick-access-tile">
          <span class="quick-access-tile-emoji">🪪</span>
          <div>
            <p class="quick-access-tile-title">Membership</p>
            <p class="quick-access-tile-sub">Legacy card</p>
          </div>
        </button>
      </div>
    </div>
  </div>

  
  <?php elseif($tab === 'wallet'): ?>
  <div class="anim-fade-up page-pad" style="padding-top:12px;padding-bottom:12px;"
       x-data="{ open: $wire.entangle('showHistory') }">

    
    <section class="wallet-balance-card">
      <div class="wallet-balance-icon">✦</div>
      <p class="wallet-balance-amount"><?php echo e(number_format($this->coinsBalance)); ?></p>
      <p class="wallet-balance-label">Jannah Coins</p>
    </section>

    
    <section class="referral-section" style="margin-top:12px;">
      <h2>Invite a Sister, Earn 25 Coins</h2>
      <p>When a sister joins using your link, you both benefit</p>
      <div class="referral-code-box">
        <p class="referral-code-text"><?php echo e($this->referralLink); ?></p>
      </div>
      <div style="margin-top:12px;" x-data="{ copied: false }">
        <button type="button" class="referral-copy-btn"
          x-on:click="navigator.clipboard.writeText('<?php echo e($this->referralLink); ?>'); copied = true; setTimeout(() => copied = false, 2000)"
          x-text="copied ? 'Copied! ✓' : 'Copy Link'">
        </button>
      </div>
      <p class="referral-stat"><?php echo e($this->referralCount); ?> sister(s) joined with your link</p>
    </section>

    
    <section class="wallet-history">
      <button type="button" wire:click="toggleHistory" class="wallet-history-toggle">
        <span class="wallet-history-toggle-text">View History</span>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.5" class="wallet-history-toggle-icon"
             x-bind:style="open ? 'transform:rotate(180deg)' : ''">
          <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/>
        </svg>
      </button>

      <div x-show="open" x-transition x-cloak style="margin-top:16px;">
        <div class="wallet-history-header">
          <span>Date</span>
          <span>Reason</span>
          <span style="text-align:right;">Amount</span>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="wallet-history-row">
            <span><?php echo e($row->created_at->hijri('d M Y')); ?></span>
            <span><?php echo e(match ($row->reason) {
                'onboarding' => 'Welcome gift',
                'referral' => 'Referral bonus',
                'manual' => 'Admin award',
                'admin_adjustment' => 'Adjustment',
                default => ucfirst(str_replace('_', ' ', $row->reason)),
            }); ?></span>
            <span class="wallet-history-amount <?php echo e($row->amount >= 0 ? 'wallet-history-positive' : 'wallet-history-negative'); ?>">
              <?php echo e($row->amount >= 0 ? '+' : ''); ?><?php echo e($row->amount); ?>

            </span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div class="wallet-history-links"><?php echo e($this->history->links()); ?></div>
      </div>
    </section>
  </div>

  
  <?php elseif($tab === 'membership'): ?>
  <div class="anim-fade-up page-pad" style="padding-top:16px;padding-bottom:16px;">

    
    <div style="margin-bottom:20px;">
      <p class="section-label profile-section-label">Badges</p>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($this->badges->isNotEmpty()): ?>
        <div class="badge-scroll">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userBadge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="badge-item">
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($userBadge->badge?->icon_path): ?>
                <img src="<?php echo e(Storage::url($userBadge->badge->icon_path)); ?>"
                     alt="<?php echo e($userBadge->badge->name); ?>"
                     class="badge-icon">
              <?php else: ?>
                <div class="badge-icon-placeholder">✦</div>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              <p class="badge-name"><?php echo e($userBadge->badge?->name); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
      <?php else: ?>
        <p class="membership-empty">Badges will appear here as you earn them</p>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div style="text-align:center;">
      <p class="section-label profile-section-label">Legacy Card</p>
      <div class="membership-legacy-preview">
        <div class="membership-legacy-header">
          <img src="<?php echo e(asset('images/img1.png')); ?>" alt="TMC" class="membership-legacy-logo">
          <p class="membership-legacy-name"><?php echo e($displayName); ?></p>
          <p class="membership-legacy-coins"><?php echo e(number_format($this->coinsBalance)); ?> coins</p>
        </div>
      </div>
      <a href="<?php echo e(route('profile.legacy-card')); ?>" class="membership-legacy-link">
        View Full Card →
      </a>
    </div>
  </div>

  
  <?php elseif($tab === 'notifications'): ?>
  <div class="anim-fade-up page-pad" style="padding-top:12px;padding-bottom:12px;">

    
    <a href="<?php echo e(route('profile.notifications')); ?>" class="notif-pref-link">
      <span class="notif-pref-text">⚙️ Notification Preferences</span>
      <span class="notif-pref-arrow">›</span>
    </a>

    
    <?php ($notifications = $this->notifications); ?>
    <?php ($unread = $this->unreadCount); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notifications->count() > 0): ?>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($unread > 0): ?>
        <button type="button" wire:click="markAllAsRead" class="notif-mark-all">
          <span class="notif-mark-all-text">Mark all as read</span>
          <span class="notif-mark-all-icon">✓</span>
        </button>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <div class="notif-list">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="notif-card <?php echo e($notification->read_at ? '' : 'notif-card-unread'); ?>"
               wire:click="markAsRead('<?php echo e($notification->id); ?>')"
               wire:key="notif-<?php echo e($notification->id); ?>">
            <div class="notif-item-inner">
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$notification->read_at): ?>
                <span class="notif-dot"></span>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              <div class="notif-item-body">
                <p class="notif-title"><?php echo e($notification->data['title'] ?? $notification->type); ?></p>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($notification->data['body'])): ?>
                  <p class="notif-body"><?php echo e($notification->data['body']); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <p class="notif-time"><?php echo e($notification->created_at->diffForHumans()); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
      <div class="notif-list-links"><?php echo e($notifications->links()); ?></div>
    <?php else: ?>
      <div class="notif-list-empty">
        <p class="notif-list-empty-icon">🔔</p>
        <p class="notif-list-empty-title">No notifications yet</p>
        <p class="notif-list-empty-sub">Updates and announcements will appear here</p>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  
  <?php elseif($tab === 'referrals'): ?>
  <div class="anim-fade-up page-pad" style="padding-top:12px;padding-bottom:12px;">

    
    <section class="referral-hero">
      <p class="referral-hero-count"><?php echo e($this->referralCount); ?></p>
      <p class="referral-hero-label">Sisters Joined</p>
    </section>

    
    <section class="referral-card">
      <h3>Share Your Link</h3>
      <p class="referral-card-sub">Earn 25 coins for each sister who joins</p>
      <div class="referral-code-box" style="background:var(--ivory);">
        <p class="referral-code-text"><?php echo e($this->referralLink); ?></p>
      </div>
      <div style="margin-top:12px;" x-data="{ copied: false }">
        <button type="button" class="referral-copy-btn" style="width:100%;"
          x-on:click="navigator.clipboard.writeText('<?php echo e($this->referralLink); ?>'); copied = true; setTimeout(() => copied = false, 2000)"
          x-text="copied ? 'Copied! ✓' : 'Copy Referral Link'">
        </button>
      </div>
    </section>

    
    <?php ($referrals = $this->referrals); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($referrals->count() > 0): ?>
      <div>
        <p class="section-label profile-section-label">Your Referrals</p>
        <div class="referral-list">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="referral-item">
              <div class="referral-avatar">
                <?php echo e(strtoupper(mb_substr($referral->referred?->name ?? '?', 0, 1))); ?>

              </div>
              <div style="flex:1;min-width:0;">
                <p class="referral-name"><?php echo e($referral->referred?->name ?? 'Unknown'); ?></p>
                <p class="referral-date">Joined <?php echo e($referral->created_at->diffForHumans()); ?></p>
              </div>
              <span class="referral-amount">+25</span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <div class="referral-list-empty">
        <p class="referral-list-empty-emoji">🤝</p>
        <p class="referral-list-empty-title">No referrals yet</p>
        <p class="referral-list-empty-sub">Share your link to invite sisters</p>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  
  <?php elseif($tab === 'settings'): ?>
  <div class="anim-fade-up page-pad" style="padding-top:12px;padding-bottom:12px;">
    <div class="settings-list">
      <a href="<?php echo e(route('profile.edit')); ?>" class="settings-item">
        <span>Edit Profile</span>
        <span class="settings-arrow">›</span>
      </a>
      <a href="<?php echo e(route('profile.notifications')); ?>" class="settings-item">
        <span>Notification Preferences</span>
        <span class="settings-arrow">›</span>
      </a>
      <a href="<?php echo e(route('password.change')); ?>" class="settings-item">
        <span>Change Password</span>
        <span class="settings-arrow">›</span>
      </a>
      <a href="<?php echo e(route('profile.legacy-card')); ?>" class="settings-item">
        <span>Legacy Card</span>
        <span class="settings-arrow">›</span>
      </a>
      <form method="POST" action="<?php echo e(route('logout')); ?>" class="settings-logout-form">
        <?php echo csrf_field(); ?>
        <button type="submit" class="settings-logout-btn">Logout</button>
      </form>
    </div>
  </div>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/profile/profile-screen.blade.php ENDPATH**/ ?>