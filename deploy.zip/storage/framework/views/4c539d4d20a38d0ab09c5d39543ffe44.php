<div class="space-y-6">
    <a href="<?php echo e(route('community')); ?>" class="inline-flex items-center text-[13px] font-medium text-teal">&larr; Community</a>

    <section class="overflow-hidden rounded-[8px] bg-white" style="border: 1px solid var(--border);">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($space->cover_image_path): ?>
            <img src="<?php echo e(Storage::url($space->cover_image_path)); ?>" alt="<?php echo e($space->name); ?>" class="max-h-[200px] w-full object-cover">
        <?php else: ?>
            <div class="h-[100px] w-full bg-teal"></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="space-y-6 p-5">
            <div>
                <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($space->name); ?></h1>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($space->is_youth_space): ?>
                    <span class="mt-3 inline-flex rounded-full bg-gold-pale px-2.5 py-1 text-[11px] font-medium text-gold">Youth Space</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <p class="mt-4 text-[0.9rem] font-light leading-8 text-ink-md"><?php echo e($space->description); ?></p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($space->guidelines): ?>
                <div class="rounded-[6px] bg-ivory p-4" style="border-left: 3px solid var(--gold);">
                    <h2 class="text-sm font-semibold text-ink">Community Guidelines</h2>
                    <p class="mt-2 text-[0.875rem] font-light leading-7 text-ink-soft"><?php echo e($space->guidelines); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($events->isNotEmpty()): ?>
                <div class="space-y-3">
                    <p class="text-[11px] uppercase tracking-[1.2px] text-ink-soft">Upcoming Halaqahs</p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('events.show', $event->slug)); ?>" class="block rounded-[8px] bg-white p-4 no-underline" style="border: 1px solid var(--border);">
                            <p class="text-sm font-semibold text-ink"><?php echo e($event->title); ?></p>
                            <p class="mt-1 text-[12px] font-light text-ink-soft"><?php echo e($event->event_date->hijri('d M Y, g:ia')); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($resources->isNotEmpty()): ?>
                <div class="space-y-3">
                    <p class="text-[11px] uppercase tracking-[1.2px] text-ink-soft">Resources</p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('resources.show', $resource->slug)); ?>" class="flex items-center justify-between rounded-[8px] bg-white p-4 no-underline" style="border: 1px solid var(--border);">
                            <p class="text-sm font-semibold text-ink"><?php echo e($resource->title); ?></p>
                            <span class="inline-flex rounded-full bg-teal-lt px-2.5 py-1 text-[11px] font-medium text-teal"><?php echo e(str_replace('_', ' ', $resource->category)); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($space->external_link): ?>
                <a href="<?php echo e($space->external_link); ?>" target="_blank" rel="noreferrer" class="inline-flex min-h-11 w-full items-center justify-center bg-teal px-5 text-[12.5px] font-semibold uppercase tracking-[1.2px] text-white no-underline" style="border-radius: 2px;">Join Group →</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/community/space-detail.blade.php ENDPATH**/ ?>