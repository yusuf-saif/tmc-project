<div
    x-data="{
        showModal: <?php echo \Illuminate\Support\Js::from($showModal)->toHtml() ?>,
        currentIndex: <?php echo \Illuminate\Support\Js::from($currentIndex)->toHtml() ?>,
    }"
    x-effect="showModal = $wire.showModal; currentIndex = $wire.currentIndex"
    wire:poll.5s="loadAnnouncements"
    style="display:none;"
>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($currentAnnouncement)): ?>
    <template x-if="showModal && $wire.currentAnnouncement">
        <div class="announce-overlay"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-end="opacity-0">

            
            <div class="announce-backdrop"
                 <?php if($currentAnnouncement['dismissible'] ?? false): ?>
                 wire:click="dismiss"
                 <?php endif; ?>
            ></div>

            
            <div class="announce-modal"
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 scale-95"
                 x-transition:enter-end="opacity-100 scale-100"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-end="opacity-0 scale-95">

                
                <div class="announce-type-bar announce-type-<?php echo e($currentAnnouncement['type'] ?? 'info'); ?>"></div>

                
                <div class="announce-content">
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($currentAnnouncement['priority'] ?? 'medium') === 'high'): ?>
                    <span class="announce-priority announce-priority-high">Urgent</span>
                    <?php elseif(($currentAnnouncement['priority'] ?? 'medium') === 'medium'): ?>
                    <span class="announce-priority announce-priority-medium">Important</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <h3 class="announce-title"><?php echo e($currentAnnouncement['title'] ?? ''); ?></h3>
                    <div class="announce-body"><?php echo $currentAnnouncement['body'] ?? ''; ?></div>
                </div>

                
                <div class="announce-actions">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($currentAnnouncement['dismissible'] ?? false) && count($announcements) > 1): ?>
                    <button wire:click="dismissAll" wire:loading.attr="disabled" class="announce-dismiss-all">
                        Dismiss All (<?php echo e(count($announcements) - $currentIndex); ?>)
                    </button>
                    <?php else: ?>
                    <span></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="announce-btn-group">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($currentAnnouncement['dismissible'] ?? false): ?>
                        <button wire:click="dismiss" wire:loading.attr="disabled" class="announce-got-it">
                            Got it
                        </button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($announcements) > 1): ?>
                <div class="announce-counter">
                    <span class="announce-counter-text"><?php echo e($currentIndex + 1); ?> of <?php echo e(count($announcements)); ?></span>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </template>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/announcement-popup.blade.php ENDPATH**/ ?>