<div class="space-y-6">
    <a href="<?php echo e(route('events')); ?>" class="inline-flex items-center text-[13px] font-medium text-teal">&larr; All Events</a>

    <section class="overflow-hidden rounded-[8px] bg-white" style="border:1px solid var(--border);">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->cover_image_path): ?>
            <img src="<?php echo e(asset('storage/'.$event->cover_image_path)); ?>" alt="<?php echo e($event->title); ?>" class="max-h-[240px] w-full object-cover">
        <?php else: ?>
            <div class="flex h-[120px] items-center justify-center bg-teal text-center text-white">
                <div>
                    <p class="font-display text-4xl leading-none">TMC</p>
                    <p class="mt-2 font-arabic text-3xl leading-none">م</p>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="space-y-5 p-5">
            <h1 class="font-display text-[2rem] leading-none text-teal-dk"><?php echo e($event->title); ?></h1>

            <div class="space-y-2 text-sm font-light text-ink-soft">
                <p>📅 <?php echo e($event->event_date->hijri('d M Y · H:i')); ?></p>
                <p>
                    📍
                    <span class="location-badge location-badge-<?php echo e($event->location_type === 'online' ? 'online' : ($event->location_type === 'in_person' ? 'person' : 'hybrid')); ?>">
                        <?php echo e(match($event->location_type) { 'online' => 'Online', 'in_person' => 'In Person', 'hybrid' => 'Hybrid' }); ?>

                    </span>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->location_detail): ?>
                        <span class="ml-2"><?php echo e($event->location_detail); ?></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
                <p>👥 <?php echo e($event->active_rsvps_count); ?> people going</p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->status === 'cancelled'): ?>
                <div class="event-cancelled">This event has been cancelled</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="text-[0.9rem] font-light leading-8 text-ink-md">
                <?php echo $event->description; ?>

            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->cover_image_path): ?>
            <img src="<?php echo e(asset('storage/'.$event->cover_image_path)); ?>" alt="<?php echo e($event->title); ?>"
                 class="w-full object-cover">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="space-y-5 p-5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->external_link): ?>
                <a href="<?php echo e($event->external_link); ?>" target="_blank" rel="noreferrer"
                   class="btn-teal-outline" style="text-decoration:none;">Join Online →</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($event->status !== 'cancelled' && $event->event_date >= now()): ?>
                <div class="event-rsvp-box space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isRsvpd): ?>
                        <button type="button" wire:click="rsvp" class="btn-gold-full"
                                wire:loading.attr="disabled">
                            RSVP - I'll be there
                        </button>
                    <?php else: ?>
                        <p class="text-center font-display text-3xl text-teal">You're going, insha'Allah ✓</p>
                        <button type="button" wire:click="cancelRsvp"
                                class="btn-teal-outline" style="width:100%;"
                                wire:loading.attr="disabled">
                            Cancel RSVP
                        </button>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>
</div>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/resources/views/livewire/events/event-detail.blade.php ENDPATH**/ ?>