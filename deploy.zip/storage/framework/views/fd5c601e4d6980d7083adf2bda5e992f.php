<h2
    <?php echo e($attributes->class(['fi-modal-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /Users/saifyusuph/Downloads/tmc-project/vendor/filament/support/resources/views/components/modal/heading.blade.php ENDPATH**/ ?>